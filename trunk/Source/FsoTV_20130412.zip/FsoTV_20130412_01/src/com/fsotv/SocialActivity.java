package com.fsotv;

import android.app.Activity;
import android.os.Bundle;

public class SocialActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_social);
	}


}
