/**
 * 
 */
package com.fsotv.vo;

/**
 * @author CuongVM1
 *
 */
public class VideoContentVO {

}
